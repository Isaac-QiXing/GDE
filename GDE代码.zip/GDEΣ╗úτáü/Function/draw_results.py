import matplotlib.pyplot as plt
import os

def draw_results(list, function_name, dimension, figure_save_path):
    plt.figure(figsize=(8, 6))
    x0 = range(0, len(list[0]))
    x1 = range(0, len(list[1]))
    x2 = range(0, len(list[2]))
    x3 = range(0, len(list[3]))
    x4 = range(0, len(list[4]))
    x5 = range(0, len(list[5]))
    y0 = list[0]
    y1 = list[1]
    y2 = list[2]
    y3 = list[3]
    y4 = list[4]
    y5 = list[5]

    plt.plot(x0, y0, color='salmon', marker='.', linestyle='-', label='M-SGD')
    plt.plot(x1, y1, color='cyan', marker='.', linestyle='-', label='M-PGD')
    plt.plot(x2, y2, color='gold', marker='.', linestyle='-', label='EA')
    plt.plot(x3, y3, color='darkgreen', marker='.', linestyle='-', label='ESGD')
    plt.plot(x4, y4, color='royalblue', marker='.', linestyle='-', label='EGD')
    plt.plot(x5, y5, color='mediumorchid', marker='.', linestyle='-', label='GDE')

    plt.xlabel('Epoches')
    plt.ylabel('function f')
    plt.legend(loc='best')
    # 指定图片保存路径
    fig_name = function_name + ":" + str(dimension) + "D"
    if not os.path.exists(figure_save_path):
        os.makedirs(figure_save_path)  # 如果不存在目录figure_save_path，则创建
    plt.savefig(os.path.join(figure_save_path, fig_name), dpi=300)  # 分别命名图片
    plt.close()


