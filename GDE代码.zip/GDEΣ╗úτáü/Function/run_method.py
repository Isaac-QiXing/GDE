import numpy as np
import pandas as pd
from PGD import MGD
from EA import EA
from PGD import MPGD
from ESGD import ESGD
from EGD import EGD
from GDE import GDE
from all_function import select_function
from draw_results import draw_results
import time


def run_method(repeat, budget, history_all, g_history_all):
    history_mean = []
    history_std = []
    history_min = []
    for j in range(budget):
        his = []
        for h in range(len(history_all)):
            his.append(history_all[h][j])
        history_mean.append(np.mean(his))
        history_std.append(np.std(his))
        g_min = []
        for gh in range(len(g_history_all)):
            g_min.append(g_history_all[gh][j])
        history_min.append(min(g_min))
    return history_mean, history_std, history_min

def out_results(history_mean, history_std, history_min):
    mean = history_mean[-1]
    std = history_std[-1]
    best = history_min[-1]
    print("mean:{}; std:{}; best:{}".format(mean, std, best))
    return mean, std, best


def RUN(function_name, population_size, dimension, learning_rate, budget, repeat, seed,
        gradient_thresh, mutate_thresh, mutate_strength, gd_budget, evo_budget, pop_strength,
        mutate_turns , if_escape_fitness, niche_size, F, fitness_p, figure_save_path):

    f, f_gradient, x_min, x_max = select_function(function_name)
    # ========================Multi-GD=====================================
    history_all, g_history_all = [], []
    print("Running MGD: ")
    start = time.time()
    for i in range(repeat):
        mgd = MGD(learning_rate, budget, population_size, dimension)
        history, g_history = mgd.MGD(x_min, x_max, f, f_gradient)
        history_all.append(history)
        g_history_all.append(g_history)
    end = time.time()
    time_MGD = (end - start)/60
    history_MGD, history_std_MGD, best_history_MGD = run_method(repeat, budget, history_all, g_history_all)
    out_results(history_MGD, history_std_MGD, best_history_MGD)

    # # ==========================Multi-PGD===================================
    history_all, g_history_all = [], []
    print("Running PGD: ")
    start = time.time()
    for i in range(repeat):
        mpgd = MPGD(learning_rate, budget, population_size, dimension,
                    mutate_thresh, mutate_strength, gradient_thresh)
        history, best_history = mpgd.MPGD(x_min, x_max, f, f_gradient)
        history_all.append(history)
        g_history_all.append(best_history)
    end = time.time()
    time_MPGD = (end - start) / 60
    history_MPGD, history_std_MPGD, best_history_MPGD = run_method(repeat, budget, history_all, g_history_all)
    out_results(history_MPGD, history_std_MPGD, best_history_MPGD)
    # =============================EA================================
    history_all, g_history_all = [], []
    print("Running EA: ")
    start = time.time()
    for i in range(repeat):
        ea = EA(population_size, mutate_strength, seed, budget, dimension)
        history, best_history = ea.EA(x_min, x_max, f)
        history_all.append(history)
        g_history_all.append(best_history)
    end = time.time()
    time_EA = (end - start) / 60
    history_EA, history_std_EA, best_history_EA = run_method(repeat, budget, history_all, g_history_all)
    out_results(history_EA, history_std_EA, best_history_EA)
    # # ============================ESGD=================================
    history_all, g_history_all = [], []
    print("Running ESGD: ")
    for i in range(repeat):
        esgd = ESGD(population_size, mutate_strength, learning_rate, seed, budget,
                    gd_budget, evo_budget, dimension)
        history, best_history = esgd.ESGD(x_min, x_max, f, f_gradient)
        history_all.append(history)
        g_history_all.append(best_history)
    end = time.time()
    time_ESGD = (end - start) / 60
    history_ESGD, history_std_ESGD, best_history_ESGD = run_method(repeat, budget, history_all, g_history_all)
    out_results(history_ESGD, history_std_ESGD, best_history_ESGD)
    # # =============================EGD================================
    history_all, g_history_all = [], []
    print("Running EGD: ")
    start = time.time()
    for i in range(repeat):
        egd = EGD(population_size, dimension, pop_strength, mutate_strength, if_escape_fitness,
                  budget, gradient_thresh, mutate_thresh, learning_rate, mutate_turns)
        history, best_history = egd.EGD(x_min, x_max, f, f_gradient)
        history_all.append(history)
        g_history_all.append(best_history)
    end = time.time()
    time_EGD = (end - start) / 60
    history_EGD, history_std_EGD, best_history_EGD = run_method(repeat, budget, history_all, g_history_all)
    out_results(history_EGD, history_std_EGD, best_history_EGD)
    # ===============================GDE=========================================
    history_all, g_history_all = [], []
    print("Running GDE: ")
    start = time.time()
    for i in range(repeat):
        gde = GDE(population_size, dimension, niche_size, budget, F, fitness_p, learning_rate)
        history, best_history = gde.GDE(x_min, x_max, f, f_gradient)
        history_all.append(history)
        g_history_all.append(best_history)
    end = time.time()
    time_GDE = (end - start) / 60
    history_GDE, history_std_GDE, best_history_GDE = run_method(repeat, budget, history_all, g_history_all)
    out_results(history_GDE, history_std_GDE, best_history_GDE)
    # ==================================draw-results=========================================
    list_history = [history_MGD, history_MPGD, history_EA, history_ESGD, history_EGD, history_GDE]
    draw_results(list_history, function_name, dimension, figure_save_path)

    function_name_best = function_name + " best"
    list_best_history = [best_history_MGD, best_history_MPGD, best_history_EA,
                         best_history_ESGD, best_history_EGD, best_history_GDE]
    draw_results(list_best_history, function_name_best, dimension, figure_save_path)
    # ==================================time====================
    run_time = [[time_MGD], [time_MPGD], [time_EA], [time_ESGD], [time_EGD], [time_GDE]]
    print("runtime:")
    print("MGD: {}min; MPGD: {}min; EA:{}; ESGD: {}min; EGD:{}min; GDE: {}min".format(run_time[0][0],run_time[1][0],run_time[2][0],
                                                                                      run_time[3][0], run_time[4][0],run_time[5][0]))

    index = ["MGD", "MPGD", "EA", "ESGD", "EGD", "GDE"]
    columns = ["runtime"]
    running_time = pd.DataFrame(run_time, index=index, columns=columns)
    path = figure_save_path + "/runtime" + str(dimension) + "D" + ".csv"
    running_time.to_csv(path)
    # ==================================store=========================================
    pd_MGD = pd.DataFrame([history_MGD], index=["MGD"])
    pd_MPGD = pd.DataFrame([history_MPGD], index=["MPGD"])
    pd_EA = pd.DataFrame([history_EA], index=["EA"])
    pd_ESGD = pd.DataFrame([history_ESGD], index=["ESGD"])
    pd_EGD = pd.DataFrame([history_EGD], index=["EGD"])
    pd_GDE = pd.DataFrame([history_GDE], index=["EAGD"])
    history = pd.concat([pd_MGD, pd_MPGD, pd_EA, pd_ESGD, pd_EGD, pd_GDE])
    path = figure_save_path + "/results_history" + str(dimension) + "D" + ".csv"
    history.to_csv(path)

    pd_MGD = pd.DataFrame([best_history_MGD], index=["MGD"])
    pd_MPGD = pd.DataFrame([best_history_MPGD], index=["MPGD"])
    pd_EA = pd.DataFrame([best_history_EA], index=["EA"])
    pd_ESGD = pd.DataFrame([best_history_ESGD], index=["ESGD"])
    pd_EGD = pd.DataFrame([best_history_EGD], index=["EGD"])
    pd_GDE = pd.DataFrame([best_history_GDE], index=["GDE"])
    best_history = pd.concat([pd_MGD, pd_MPGD, pd_EA, pd_ESGD, pd_EGD, pd_GDE])
    path = figure_save_path + "/results_best_history" + str(dimension) + "D" + ".csv"
    best_history.to_csv(path)

    pd_MGD = pd.DataFrame([history_std_MGD], index=["GD"])
    pd_MPGD = pd.DataFrame([history_std_MPGD], index=["PGD"])
    pd_EA = pd.DataFrame([history_std_EA], index=["DE"])
    pd_ESGD = pd.DataFrame([history_std_ESGD], index=["ESGD"])
    pd_EGD = pd.DataFrame([history_std_EGD], index=["EGD"])
    pd_GDE = pd.DataFrame([history_std_GDE], index=["EAGD"])
    std_history = pd.concat([pd_MGD, pd_MPGD, pd_EA, pd_ESGD, pd_EGD, pd_GDE])
    path = figure_save_path + "/results_history_std" + str(dimension) + "D" + ".csv"
    std_history.to_csv(path)
