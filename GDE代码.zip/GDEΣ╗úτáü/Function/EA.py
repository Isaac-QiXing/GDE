'''
Evolutionary Algorithm
'''

import numpy as np
import random
import copy
from all_function import select_function

def get_fitness(x, f):
    fitness = f(x)
    return fitness

class EA():
    def __init__(self, population_size, mutate_strength, seed, budget, dimension):

        self.x_fitness = None
        self.population_size = population_size
        self.mutate_strength = mutate_strength
        self.seed = seed
        self.M = int(self.population_size / 2)
        np.random.seed(self.seed)
        self.budget = budget
        self.dimension = dimension
        self.t = 0
        self.optimizer = None


    def initial(self, x_min, x_max):
        population = np.random.uniform(x_min, x_max, [self.population_size, self.dimension])
        return population

    def Fitness(self, population, f):
        fitness = [self.get_fitness_EA(population[p], f) for p in range(len(population))]
        return fitness

    def get_fitness_EA(self, x, f):
        return get_fitness(x, f)


    def EA_mutate(self, x):
        return x + np.random.uniform(-self.mutate_strength, self.mutate_strength, [self.dimension])

    def p_distance(self, x, y):
        dist = (np.square(np.sum((np.array(x) - np.array(y))))) ** 0.5
        return dist

    def is_domin(self, x, x_min, x_max):
        for i in range(len(x)):
            if x[i] < x_min or x[i] > x_max:
                if self.p_distance(x[i], x_min) < self.p_distance(x[i], x_max):
                    x[i] = x_min
                else:
                    x[i] = x_max
        return x

    def EA_generate_offspring(self, population, f, x_min, x_max):
        fitness = self.Fitness(population, f)
        best_idx = np.argmin(fitness)
        offspring = np.zeros([self.population_size, self.dimension])
        for i in range(self.population_size):
            offspring[i] = self.is_domin(self.EA_mutate(population[best_idx]), x_min, x_max)
        return offspring

    def selection(self, population, offspring, f):
        new_x = np.zeros([self.population_size, self.dimension])
        fitness = self.Fitness(population, f)
        x_idx = np.argsort(fitness)
        offspring_fitness = self.Fitness(offspring, f)
        off_idx = np.argsort(offspring_fitness)
        x_ite = 0
        off_ite = 0
        for i in range(self.M):
            if offspring_fitness[off_idx[off_ite]] < fitness[x_idx[x_ite]]:
                new_x[i] = copy.deepcopy(offspring[off_idx[off_ite]])
                off_ite += 1
            else:
                new_x[i] = copy.deepcopy(population[x_idx[x_ite]])
                x_ite += 1
        for j in range(self.population_size - self.M):
            if np.random.rand() < 0.5:
                idx = np.random.randint(x_ite + 1, self.population_size)
                new_x[self.M + j] = copy.deepcopy(population[x_idx[idx]])
            else:
                idx = np.random.randint(off_ite + 1, self.population_size)
                new_x[self.M + j] = copy.deepcopy(offspring[off_idx[idx]])
        population = copy.deepcopy(new_x)
        population_backup = copy.deepcopy(population)
        return population, population_backup

    def EA(self, x_min, x_max, f):
        population = self.initial(x_min, x_max)
        fitness = self.Fitness(population, f)
        history = [np.min(fitness)]
        best_history = [np.min(fitness)]
        while self.t < self.budget:
            offspring = self.EA_generate_offspring(population, f, x_min, x_max)
            population, population_backup = self.selection(population, offspring, f)
            self.t += 1
            fitness = self.Fitness(population, f)
            history.append(np.min(fitness))
            best_history.append(min(np.min(fitness), best_history[-1]))
        return history, best_history