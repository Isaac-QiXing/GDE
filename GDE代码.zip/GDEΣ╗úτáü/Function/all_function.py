import numpy as np


def select_function(function_name):
    if function_name == "Equal_maxima":
        x_min, x_max = 0, 1

        ##目标函数
        def f(x):
            y = np.sin(5 * np.pi * x) ** 6
            return y

        ##目标函数梯度计算
        def f_gradient(x):
            grad = 30 * np.pi * np.sin(5 * np.pi * x) ** 5 * np.cos(5 * np.pi * x)
            return grad

    elif function_name == "Uneven_decreasing_maxima":
        x_min, x_max = 0, 1

        def f(x):
            y = (x * np.sin(5 * np.pi * x) ** 6)
            return y

        def f_gradient(x):
            grad = 30 * np.pi * x * np.sin(5 * np.pi * x) ** 5 * np.cos(5 * np.pi * x) + np.sin(5 * np.pi * x) ** 6
            return grad

    elif function_name == "Himmelblau":
        x_min, x_max = -6, 6

        def f(x):
            y = 200 - (x[0] ** 2 + x[1] - 11) ** 2 - (x[0] + x[1] ** 2 - 7) ** 2
            return y

        def f_gradient(x):
            grad_x1 = -4 * x[0] * (x[0] ** 2 + x[1] - 11) - 2 * x[0] - 2 * x[1] ** 2 + 14
            grad_x2 = -2 * x[0] ** 2 - 4 * x[1] * (x[0] + x[1] ** 2 - 7) - 2 * x[1] + 22
            grad = (grad_x1, grad_x2)
            return grad

    elif function_name == "Six_hump_camel_back":
        x_min, x_max = -2, 2

        def f(x):
            y = -4 * ((4 - 2.1 * (x[0] ** 2) + ((x[0] ** 4) / 3)) * (x[0] ** 2) + x[0] * x[1] + (
                        4 * (x[1] ** 2) - 4) * (x[1] ** 2))
            return y

        def f_gradient(x):
            N = len(x)
            grad = np.zeros(N)
            grad[0] = -4 * x[0] ** 2 * (4 * x[0] ** 3 / 3 - 4.2 * x[0]) - 8 * x[0] * (
                        x[0] ** 4 / 3 - 2.1 * x[0] ** 2 + 4) - 4 * x[1]
            grad[1] = -4 * x[0] - 32 * x[1] ** 3 - 8 * x[1] * (4 * x[1] ** 2 - 4)
            return grad

    #             grad_x1 = -4*x[0]**2*(4*x[0]**3/3 - 4.2*x[0]) - 8*x[0]*(x[0]**4/3 - 2.1*x[0]**2 + 4) - 4*x[1]
    #             grad_x2 = -4*x[0] - 32*x[1]**3 - 8*x[1]*(4*x[1]**2 - 4)
    #             grad = (grad_x1, grad_x2)

    elif function_name == "Shubert":
        x_min, x_max = -10, 10

        def f(x):
            f_1 = (1 * np.cos((1 + 1) * x[0] + 1)) + (2 * np.cos((2 + 1) * x[0] + 2)) + (
                        3 * np.cos((3 + 1) * x[0] + 3)) + (
                          4 * np.cos((4 + 1) * x[0] + 4)) + (5 * np.cos((5 + 1) * x[0] + 5))
            f_2 = (1 * np.cos((1 + 1) * x[1] + 1)) + (2 * np.cos((2 + 1) * x[1] + 2)) + (
                        3 * np.cos((3 + 1) * x[1] + 3)) + (
                          4 * np.cos((4 + 1) * x[1] + 4)) + (5 * np.cos((5 + 1) * x[1] + 5))
            y = -(f_1 * f_2)
            return y

        def f_gradient(x):
            grad_x1 = (2 * np.sin(2 * x[0] + 1) + 6 * np.sin(3 * x[0] + 2) + 12 * np.sin(4 * x[0] + 3) + 20 * np.sin(
                5 * x[0] + 4) + 30 * np.sin(6 * x[0] + 5)) * (
                                  np.cos(2 * x[1] + 1) + 2 * np.cos(3 * x[1] + 2) + 3 * np.cos(
                              4 * x[1] + 3) + 4 * np.cos(5 * x[1] + 4) + 5 * np.cos(6 * x[1] + 5))
            grad_x2 = (-2 * np.sin(2 * x[1] + 1) - 6 * np.sin(3 * x[1] + 2) - 12 * np.sin(4 * x[1] + 3) - 20 * np.sin(
                5 * x[1] + 4) - 30 * np.sin(6 * x[1] + 5)) * (
                                  -np.cos(2 * x[0] + 1) - 2 * np.cos(3 * x[0] + 2) - 3 * np.cos(
                              4 * x[0] + 3) - 4 * np.cos(5 * x[0] + 4) - 5 * np.cos(6 * x[0] + 5))
            grad = (grad_x1, grad_x2)
            return grad

    elif function_name == "Grienwank":
        x_min, x_max = -10, 10

        def f(x):
            y = (x[0] ** 2) / 4000 + (x[1] ** 2) / 4000 - np.cos(x[0] / np.sqrt(1)) * np.cos(x[1] / np.sqrt(2)) + 1
            return y

        def f_gradient(x):
            grad_x1 = x[0] / 2000 + np.sin(x[0]) * np.cos(np.sqrt(2) * x[1] / 2)
            grad_x2 = x[1] / 2000 + np.sqrt(2) * np.sin(np.sqrt(2) * x[1] / 2) * np.cos(x[0]) / 2
            grad = (grad_x1, grad_x2)
            return grad

    elif function_name == "Bent Cigar":
        x_min, x_max = -2, 2

        def f(x):
            N = len(x)
            f_value = x[0] ** 2 + sum(100 * (x[1:N:1]) ** 2)
            return f_value

        def f_gradient(x):
            N = len(x)
            grad = np.zeros(N)
            grad[0] = 2 * x[0]
            grad[1:N:1] = 200 * np.array(x[1:N:1])
            return grad

    elif function_name == "Sphere":
        x_min, x_max = -3, 3

        def f(x):
            N = len(x)
            f_value = sum(np.array(x[0:N:1]) ** 2)
            return f_value

        def f_gradient(x):
            N = len(x)
            grad = np.zeros(N)
            grad[0:N:1] = 2 * np.array(x[0:N:1])
            return grad

    elif function_name == "Rosenbrock":
        x_min, x_max = -2.048, 2.048

        def f(x):
            N = len(x)
            f_value = sum((np.array(x[0:N - 1:1]) - 1) ** 2) + sum(
                100 * (np.array(x[0:N - 1:1]) ** 2 - np.array(x[1:N:1])) ** 2)
            return f_value

        def f_gradient(x):
            N = len(x)
            grad = np.zeros(N)
            grad[0:1:1] = 400 * np.array(x[0:1:1]) * (np.array(x[0:1:1]) ** 2 - np.array(x[1:2:1])) + 2 * (
                        np.array(x[0:1:1]) - 1)
            grad[1:N - 1:1] = -200 * (np.array(x[0:N - 2:1]) ** 2 - np.array(x[1:N - 1:1])) + 2 * (
                        np.array(x[1:N - 1:1]) - 1) + 400 * np.array(x[1:N - 1:1]) * (
                                          np.array(x[1:N - 1:1]) ** 2 - x[2:N:1])
            grad[N - 1:N:1] = -200 * (np.array(x[N - 2:N - 1:1]) ** 2 - np.array(x[N - 1:N:1]))
            return grad


    elif function_name == "Ackley":
        x_min, x_max = -10, 10

        def f(x):
            N = len(x)
            inx = 1 / N
            f_value = -20 * np.exp(-0.2 * np.sqrt(inx * sum(np.array(x[0:N:1]) ** 2))) - np.exp(
                inx * sum(np.cos(2 * np.pi * np.array(x[0:N:1])))) + 20 + np.e
            return f_value

        def f_gradient(x):
            N = len(x)
            inx = 1 / N
            grad = np.zeros(N)
            grad[0:N:1] = 4 * inx * np.array(x[0:N:1]) * np.exp(-0.2 * np.sqrt(inx * sum(np.array(x[0:N:1]) ** 2))) * (
                        1 / (np.sqrt(inx * sum(np.array(x[0:N:1]) ** 2)))) + inx * 2 * np.pi * np.sin(
                2 * np.pi * np.array(x[0:N:1])) * np.exp(inx * sum(np.cos(2 * np.pi * np.array(x[0:N:1]))))
            return grad


    elif function_name == "Griewank":
        x_min, x_max = -10, 10

        def f(x):
            N = len(x)
            index = []
            for i in range(N):
                index.append(i + 1)
            f_value = sum(np.array(x[0:N:1]) ** 2 / 4000) - np.dot(np.cos(np.array(x) / np.sqrt(index)),
                                                                   np.cos(np.array(x) / np.sqrt(index))) + 1
            return f_value

        def f_gradient(x):
            N = len(x)
            grad = np.zeros(N)
            index = []
            for i in range(N):
                index.append(i + 1)
            grad[0:N:1] = (np.array(x[0:N:1]) ** 2 / 2000) - (1 / 2) * (np.array(index)[0:N:1] ** (-3 / 2)) * np.sin(
                np.array(x) / np.sqrt(index)) * np.dot(np.cos(np.array(x) / np.sqrt(index)),
                                                       np.cos(np.array(x) / np.sqrt(index))) / (
                              np.cos(np.array(x)[0:N:1] / np.array(index)[0:N:1]))
            return grad

    elif function_name == "Restrigin":
        x_min, x_max = -5.12, 5.12

        def f(x):
            N = len(x)
            f_value = sum(np.array(x[0:N:1]) ** 2 - 10 * np.cos(2 * np.pi * np.array(x[0:N:1])) + 10)
            return f_value

        def f_gradient(x):
            N = len(x)
            grad = np.zeros(N)
            grad[0:N:1] = 2 * np.array(x[0:N:1]) + 20 * np.pi * np.sin(2 * np.pi * np.array(x[0:N:1]))
            return grad

    elif function_name == "Schwefel":
        x_min, x_max = -10, 10

        def f(x):
            N = len(x)
            f_value = - np.sum(x[0:N:1] * np.sin(np.sqrt(abs(x[0:N:1]))))
            return f_value

        def f_gradient(x):
            eps = 1e-12
            N = len(x)
            EPSILON = eps * np.eye(N)
            grad = np.zeros([N])
            fitness = f(x)
            for i in range(N):
                try:
                    grad[i] = (f(x + EPSILON[i]) - fitness) / (eps)
                except Exception as e:
                    print(e)
            return grad

    else:
        print("输入函数名称有误")

    return f, f_gradient, x_min, x_max
