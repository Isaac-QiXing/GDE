'''
GDE
'''

import numpy as np
import random
from all_function import select_function

def get_fitness(x, f):
    fitness = f(x)
    return fitness

def get_gradient(x, f_gradient):
    grad = f_gradient(x)
    return grad

class GDE():
    def __init__(self, population_size, dimension, niche_size, budget, F, fitness_p, learning_rate):
        self.population_size = population_size
        self.niche_size = niche_size
        self.dimension = dimension
        self.budget = budget
        self.F = F
        self.M = int(self.population_size / 2)
        self.fitness_p = fitness_p
        self.learning_rate = learning_rate
        self.t = 0

    def initial(self, x_min, x_max):
        population = np.random.uniform(x_min, x_max, [self.population_size, self.dimension])
        return population

    def Fitness(self, population, f):
        fitness = [get_fitness(population[p], f) for p in range(len(population))]
        return fitness

    def Gradient(self, x, f_gradient):
        grad = get_gradient(x, f_gradient)
        N = len(x)
        x[0:N:1] = x[0:N:1] - self.learning_rate * grad[0:N:1]
        return x

    def is_domin(self, x, x_min, x_max):
        for i in range(len(x)):
            if x[i] < x_min or x[i] > x_max:
                if self.p_distance(x[i], x_min) < self.p_distance(x[i], x_max):
                    x[i] = x_min
                else:
                    x[i] = x_max
        return x

    def fitness_sort(self, population, f):
        Fitness = self.Fitness(population, f)
        sort = sorted(zip(population, Fitness), key=lambda x: x[1], reverse=False)
        best_p = sort[0][0]
        return best_p, Fitness, sort

    def p_distance(self, x, y):
        dist = (np.square(np.sum((np.array(x) - np.array(y))))) ** 0.5
        return dist

    def distance_sort(self, x, population):
        Distance = np.zeros(len(population))
        for i in range(len(population)):
            Distance[i] = self.p_distance(x, population[i])
        sort = sorted(zip(population, Distance), key=lambda x: x[1], reverse=False)
        return sort

    def get_niche(self, population, f):
        Niche = []
        for i in range(int(self.population_size/self.niche_size)):
            best_p, Fitness, Fitness_sort = self.fitness_sort(population, f)
            sort = self.distance_sort(best_p, population)
            population1, niche = [], []
            for j in range(len(sort)):
                population1.append(sort[j][0])
            for k in range(self.niche_size):
                niche.append(sort[k][0])
            Niche.append(niche)
            del population1[:self.niche_size]
            population = population1
        if len(population) != 0:
            Niche.append(population)
        return Niche

    def update1(self, x, f_gradient):
        grad = self.Gradient(x, f_gradient)
        N = len(x)
        x[0:N:1] = x[0:N:1] - self.learning_rate * grad[0:N:1]
        return x

    def update2(self, x, best_x, f_gradient):
        grad = self.Gradient(x, f_gradient)
        N = len(x)
        x[0:N:1] = x[0:N:1] - self.learning_rate * grad[0:N:1] + self.F * (best_x[0:N:1]-x[0:N:1]) #+ self.F * (niche[k[0]][0:N:1] - niche[k[1]][0:N:1])
        return x

    def update3(self, x, population):
        k = np.random.randint(0, len(population), 2)
        N = len(x)
        x[0:N:1] = x[0:N:1] + self.F * (population[k[0]][0:N:1] - population[k[1]][0:N:1])
        return x

    def prob(self, x, Fitness, f):
        p = (f(x) - min(Fitness)) / (max(Fitness) - min(Fitness) + 10e-8)
        return p

    def update(self, x, best_x, population,  Fitness, f, f_gradient, x_min, x_max):
        if self.p_distance(x, best_x) == 0:
                x = self.is_domin(self.update1(x, f_gradient),x_min, x_max)
        else:
            p = self.prob(x, Fitness, f)
            if p > self.fitness_p:
                x = self.is_domin(self.update2(x, best_x, f_gradient), x_min, x_max)
            else:
                x = self.is_domin(self.update3(x, population), x_min, x_max)
        return x


    def L_select(self, x1, population, offspring_population, f):
        d_sort = self.distance_sort(x1, population)
        x_nearest = d_sort[1][0]
        if f(x1) <= f(x_nearest):
            offspring_population.append(np.array(x1))
        else:
            offspring_population.append(np.array(x_nearest))
        return offspring_population


    def GDE(self, x_min, x_max, f, f_gradient):
        population = self.initial(x_min, x_max)
        fitness = self.Fitness(population, f)
        history = [np.min(fitness)]
        best_history = [np.min(fitness)]
        population = list(population)
        while self.t < self.budget:
            Niche = self.get_niche(population, f)

            offspring_population_L = []
            for i in range(len(Niche)):
                niche = Niche[i]
                best_x, Fitness, Fitness_sort = self.fitness_sort(population, f)
                for x in niche:
                    x1 = self.update(x, best_x, population, Fitness, f, f_gradient, x_min, x_max)
                    offspring_population_L = self.L_select(x1, population, offspring_population_L, f)
            population = offspring_population_L

            self.t += 1
            fitness = self.Fitness(population, f)
            history.append(np.min(fitness))
            best_history.append(min(np.min(fitness), best_history[-1]))
        return history, best_history




