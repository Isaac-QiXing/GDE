from run_method import RUN



population_size = 10
niche_size = 2
learning_rate = 0.001
budget = 100
gd_budget = 5
evo_budget = 5
repeat = 5
gradient_thresh = 1e-2
mutate_thresh = 500
mutate_strength = 0.5
seed = 2022
pop_strength = 3
mutate_turns = mutate_thresh
if_escape_fitness = 0.1
F = .5
fitness_p = 0.1


dimensions = [100]
function_names = ["Bent Cigar"]
for dimension in dimensions:
    for function_name in function_names:
        print("{} D {}:".format(dimension, function_name))
        figure_save_path = "./results/" + str(function_name)
        RUN(function_name, population_size, dimension, learning_rate, budget, repeat, seed,
            gradient_thresh, mutate_thresh, mutate_strength, gd_budget, evo_budget, pop_strength,
            mutate_turns, if_escape_fitness, niche_size, F, fitness_p, figure_save_path)

