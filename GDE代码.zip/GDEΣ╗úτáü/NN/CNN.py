import numpy as np



# 激活函数
def relu(feature):
    '''Relu激活函数，有两种情况会使用到
    当在卷积层中使用时，feature为一个三维张量，，[行，列，通道]
    当在全连接层中使用时，feature为一个列向量'''
    return feature * (feature > 0)

def relu_prime(feature):  # 对relu函数的求导
    '''relu函数的一阶导数，间断点导数认为是0'''

    return 1 * (feature > 0)

#卷积实现

def conv(img, conv_filter):
    if len(img.shape) != 3 or len(conv_filter.shape) != 4:
        print("卷积运算所输入的维度不符合要求")
        sys.exit()

    if img.shape[-1] != conv_filter.shape[-1]:
        print("卷积输入图片与卷积核的通道数不一致")
        sys.exit()

    img_h, img_w, img_ch = img.shape
    filter_num, filter_h, filter_w, img_ch = conv_filter.shape
    feature_h = img_h - filter_h + 1
    feature_w = img_w - filter_w + 1

    # 初始化输出的特征图片，由于没有使用零填充，图片尺寸会减小
    img_out = np.zeros((feature_h, feature_w, filter_num))
    img_matrix = np.zeros((feature_h * feature_w, filter_h * filter_w * img_ch))
    filter_matrix = np.zeros((filter_h * filter_w * img_ch, filter_num))

    # 将输入图片张量转换成矩阵形式
    for j in range(img_ch):
        img_2d = np.copy(img[:, :, j])
        shape = (feature_h, feature_w, filter_h, filter_w)
        strides = (img_w, 1, img_w, 1)
        strides = img_2d.itemsize * np.array(strides)
        x_stride = np.lib.stride_tricks.as_strided(img_2d, shape=shape, strides=strides)
        x_cols = np.ascontiguousarray(x_stride)
        x_cols = x_cols.reshape(feature_h * feature_w, filter_h * filter_w)
        img_matrix[:, j * filter_h * filter_w:(j + 1) * filter_h * filter_w] = x_cols

    # 将卷积核张量转换成矩阵形式
    for i in range(filter_num):
        filter_matrix[:, i] = conv_filter[i, :].transpose(2, 0, 1).reshape(filter_w * filter_h * img_ch)

    feature_matrix = np.dot(img_matrix, filter_matrix)

    for i in range(filter_num):
        img_out[:, :, i] = feature_matrix[:, i].reshape(feature_h, feature_w)

    return img_out


'''
计算卷积核导数
'''
def conv_cal_w(out_img_delta, in_img):
    # 同样利用img2col思想加速
    img_h, img_w, img_ch = in_img.shape
    feature_h, feature_w, filter_num = out_img_delta.shape
    filter_h = img_h - feature_h + 1
    filter_w = img_w - feature_w + 1

    in_img_matrix = np.zeros([filter_h * filter_w * img_ch, feature_h * feature_w])
    out_img_delta_matrix = np.zeros([feature_h * feature_w, filter_num])

    # 将输入图片转换成矩阵形式
    for j in range(img_ch):
        img_2d = np.copy(in_img[:, :, j])
        shape = (filter_h, filter_w, feature_h, feature_w)
        strides = (img_w, 1, img_w, 1)
        strides = img_2d.itemsize * np.array(strides)
        x_stride = np.lib.stride_tricks.as_strided(img_2d, shape=shape, strides=strides)
        x_cols = np.ascontiguousarray(x_stride)
        x_cols = x_cols.reshape(filter_h * filter_w, feature_h * feature_w)
        in_img_matrix[j * filter_h * filter_w:(j + 1) * filter_h * filter_w, :] = x_cols

    # 将输出图片delta误差转换成矩阵形式
    for i in range(filter_num):
        out_img_delta_matrix[:, i] = out_img_delta[:, :, i].reshape(feature_h * feature_w)

    filter_matrix = np.dot(in_img_matrix, out_img_delta_matrix)
    nabla_conv = np.zeros([filter_num, filter_h, filter_w, img_ch])

    for i in range(filter_num):
        nabla_conv[i, :] = filter_matrix[:, i].reshape(img_ch, filter_h, filter_w).transpose(1, 2, 0)
    return nabla_conv


'''
计算卷积核偏置层的导数
'''


def conv_cal_b(out_img_delta):
    nabla_b = np.zeros((out_img_delta.shape[-1], 1))
    for i in range(out_img_delta.shape[-1]):
        nabla_b[i] = np.sum(out_img_delta[:, :, i])
    return nabla_b

# 最大池化
def pool(feature, size=2, stride=2):
    '''
    最大池化操作
    同时输出池化后的结果以及用于记录最大位置的张量，方便之后delta误差反向传播
    '''
    feature_h, feature_w, feature_ch = feature.shape
    pool_h = np.uint16((feature_h - size)/stride + 1)
    pool_w = np.uint16((feature_w - size)/stride + 1)
    feature_reshaped = feature.reshape(pool_h, feature_h//pool_h, pool_w, feature_w//pool_w, feature_ch)
    out = feature_reshaped.max(axis=1).max(axis=2)
    out_location_c = feature_reshaped.max(axis=1).argmax(axis=2)
    out_location_r = feature_reshaped.max(axis=3).argmax(axis=1)
    out_location = out_location_r * size + out_location_c
    return out, out_location

'''
池化层误差反向传播
'''
def pool_delta_error_bp(pool_out_delta, pool_out_max_location, size=2, stride=2):
    pool_h, pool_w, pool_ch = pool_out_delta.shape
    in_h = np.uint16((pool_h - 1) * stride + size)
    in_w = np.uint16((pool_w - 1) * stride + size)
    in_ch = pool_ch

    pool_out_delta_reshaped = pool_out_delta.transpose(2, 0, 1)
    pool_out_delta_reshaped = pool_out_delta_reshaped.flatten()

    pool_out_max_location_reshaped = pool_out_max_location.transpose(2, 0, 1)
    pool_out_max_location_reshaped = pool_out_max_location_reshaped.flatten()

    in_delta_matrix = np.zeros([pool_h * pool_w * pool_ch, size * size])
    in_delta_matrix[np.arange(pool_h * pool_w * pool_ch), pool_out_max_location_reshaped] = pool_out_delta_reshaped

    in_delta = in_delta_matrix.reshape(pool_ch, pool_h, pool_w, size, size)
    in_delta = in_delta.transpose(1, 3, 2, 4, 0)
    in_delta = in_delta.reshape(in_h, in_w, in_ch)
    return in_delta


'''
将一个二维矩阵上下颠倒一次再左右颠倒
'''
def rot180(conv_filters):
    rot180_filters = np.zeros((conv_filters.shape))
    for filter_num in range(conv_filters.shape[0]):
        for img_ch in range(conv_filters.shape[-1]):
            rot180_filters[filter_num,:,:,img_ch] = np.flipud(np.fliplr(conv_filters[filter_num,:,:,img_ch]))
    return rot180_filters

'''
先对每个元素进行缩放（减去最大值之后）在写入公式（防止发生溢出 无法训练
'''
def soft_max(z):
    tmp = np.max(z)
    z -= tmp  # 用于缩放每行的元素，避免溢出，有效
    z = np.exp(z)
    tmp = np.sum(z)
    z /= tmp
    return z

def add_bias(conv, bias):
    if conv.shape[-1] != bias.shape[0]:
        print("给卷积添加偏置维度出错")
    else:
        for i in range(bias.shape[0]):
            conv[:,:,i] += bias[i,0]
    return conv
