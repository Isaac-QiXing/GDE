
import pandas as pd

def tocsv(run_time, run_onetime, figure_save_path, dataname, Train_Accuracy_list, Train_cost_list,
          Test_Accuracy_list, Test_cost_list, Valid_Accuracy_list, Valid_cost_list):


    # ==================================time====================
    print("runtime:")
    print("MGD: {}min; ESGD: {}min; GDE: {}min".format(run_time[0], run_time[1], run_time[2]))

    index = ["MGD", "ESGD", "GDE"]
    columns = ["runtime"]
    running_time = pd.DataFrame(run_time, index=index, columns=columns)
    path = figure_save_path + "/runtime:" + dataname + ".csv"
    running_time.to_csv(path)
    # ==================================onetime====================
    print("run onetime:")
    print("MGD: {}s; ESGD: {}s; GDE: {}s".format(run_onetime[0][-1], (run_onetime[1][0][-1], run_onetime[1][1][-1]),
                                                 run_onetime[2][-1]))
    run_onetime = [run_onetime[0][-1], (run_onetime[1][0][-1], run_onetime[1][1][-1]), run_onetime[2][-1]]
    index = ["MGD", "ESGD", "GDE"]
    columns = ["runonetime"]
    running_time = pd.DataFrame(run_onetime, index=index, columns=columns)
    path = figure_save_path + "/run_onetime:" + dataname + ".csv"
    running_time.to_csv(path)
    # # ==================================onetime====================
    # time_MSGD = pd.DataFrame([run_onetime[0]], index=["MSGD"])
    # time_ESGD = pd.DataFrame([run_onetime[1]], index=["ESGD"])
    # time_GDE = pd.DataFrame([run_onetime[2]], index=["GDE"])
    # Time = pd.concat([time_MSGD, time_ESGD, time_GDE])
    # path = figure_save_path + "/run_one_time:" + dataname + ".csv"
    # Time.to_csv(path)
    # ==================================store=========================================
    pd_msgd = pd.DataFrame([Valid_cost_list[0]], index=["MSGD"])
    pd_esgd = pd.DataFrame([Valid_cost_list[1]], index=["ESGD"])
    pd_gde = pd.DataFrame([Valid_cost_list[2]], index=["GDE"])
    history = pd.concat([pd_msgd, pd_esgd, pd_gde])
    path = figure_save_path + "/Valid_cost:" + dataname + ".csv"
    history.to_csv(path)


    pd_msgd = pd.DataFrame([Valid_Accuracy_list[0]], index=["SGD"])
    pd_esgd = pd.DataFrame([Valid_Accuracy_list[1]], index=["ESGD"])
    pd_gde = pd.DataFrame([Valid_Accuracy_list[2]], index=["GDE"])
    history = pd.concat([pd_msgd, pd_esgd, pd_gde])
    path = figure_save_path + "/Valid_Accuracy:" + dataname + ".csv"
    history.to_csv(path)

    pd_msgd = pd.DataFrame([Train_Accuracy_list[0]], index=["SGD"])
    pd_esgd = pd.DataFrame([Train_Accuracy_list[1]], index=["ESGD"])
    pd_gde = pd.DataFrame([Train_Accuracy_list[2]], index=["GDE"])
    history = pd.concat([pd_msgd, pd_esgd, pd_gde])
    path = figure_save_path + "/Train_Accuracy:" + dataname + ".csv"
    history.to_csv(path)

    pd_msgd = pd.DataFrame([Train_cost_list[0]], index=["SGD"])
    pd_esgd = pd.DataFrame([Train_cost_list[1]], index=["ESGD"])
    pd_gde = pd.DataFrame([Train_cost_list[2]], index=["GDE"])
    history = pd.concat([pd_msgd, pd_esgd, pd_gde])
    path = figure_save_path + "/Train_cost:" + dataname + ".csv"
    history.to_csv(path)

    pd_msgd = pd.DataFrame([Test_Accuracy_list[0]], index=["SGD"])
    pd_esgd = pd.DataFrame([Test_Accuracy_list[1]], index=["ESGD"])
    pd_gde = pd.DataFrame([Test_Accuracy_list[2]], index=["GDE"])
    history = pd.concat([pd_msgd, pd_esgd, pd_gde])
    path = figure_save_path + "/Test_Accuracy:" + dataname + ".csv"
    history.to_csv(path)

    pd_msgd = pd.DataFrame([Test_cost_list[0]], index=["SGD"])
    pd_esgd = pd.DataFrame([Test_cost_list[1]], index=["ESGD"])
    pd_gde = pd.DataFrame([Test_cost_list[2]], index=["GDE"])
    history = pd.concat([pd_msgd, pd_esgd, pd_gde])
    path = figure_save_path + "/Test_cost:" + dataname + ".csv"
    history.to_csv(path)

