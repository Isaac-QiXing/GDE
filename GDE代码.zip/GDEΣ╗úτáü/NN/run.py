from run_method import run_method

# =====================================================================
population_size = 5
niche_size = 2
learning_rate = 0.01
epochs = 10
gd_epochs = 3
evo_epochs = 2
mini_batch_size = 64
mutate_strength = 0.5
F = 0.5
fitness_p = 0.01



figure_save_path = "./results/MNIST"
dir_data = ['./data/MNIST/train-images-idx3-ubyte', './data/MNIST/train-labels-idx1-ubyte',
            './data/MNIST/t10k-images-idx3-ubyte', './data/MNIST/t10k-labels-idx1-ubyte']
# ====================================================================
train_size, test_size, fitness_size = 10, 10, 10
dataname = "MNIST: tr-" + str(train_size) + "; val-" + str(fitness_size)
run_method(population_size, mini_batch_size, epochs, learning_rate, train_size, test_size,
           fitness_size,  mutate_strength, gd_epochs, evo_epochs, niche_size, F, fitness_p,
           dataname, figure_save_path, dir_data)
