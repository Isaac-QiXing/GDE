import matplotlib.pyplot as plt
import os

def draw_results(list, title, label, figure_save_path):
    plt.figure(figsize=(8, 6))
    x0 = range(0, len(list[0]))
    x1 = range(0, len(list[1]))
    x2 = range(0, len(list[2]))
    y0 = list[0]
    y1 = list[1]
    y2 = list[2]

    plt.plot(x0, y0, color='salmon', marker='.', linestyle='-', label='M-SGD')
    plt.plot(x1, y1, color='darkgreen', marker='.', linestyle='-', label='ESGD')
    plt.plot(x2, y2, color='mediumorchid', marker='.', linestyle='-', label='GDE')
    plt.xlabel('Epoches')
    plt.ylabel(label)
    plt.legend(loc='best')
    # 指定图片保存路径
    fig_name = title
    if not os.path.exists(figure_save_path):
        os.makedirs(figure_save_path)  # 如果不存在目录figure_save_path，则创建
    plt.savefig(os.path.join(figure_save_path, fig_name), dpi=600)  # 分别命名图片
    plt.close()
