from draw import draw_results
from MSGD import MSGD
from ESGD import ESGD
from GDE import GDE
from load_data import dataset_loader, padding
from initial import population_initializer
import time
from tocsv import tocsv



def run_method(population_size, mini_batch_size, epochs, learning_rate, train_size, test_size,
               fitness_size,  mutate_strength, gd_epochs, evo_epochs, niche_size, F, fitness_p,
               dataname, figure_save_path, dir_data):

    dir_tr_image, dir_tr_label, \
    dir_te_image, dir_te_label = dir_data[0], dir_data[1], dir_data[2], dir_data[3]

    # dir_tr_image = r'./MNIST/train-images-idx3-ubyte'
    # dir_tr_label = r'./MNIST/train-labels-idx1-ubyte'
    # dir_te_image = r'./MNIST/t10k-images-idx3-ubyte'
    # dir_te_label = r'./MNIST/t10k-labels-idx1-ubyte'
    train_image, train_label, test_image, test_label = dataset_loader(dir_tr_image, dir_tr_label,
                                                                      dir_te_image, dir_te_label)
    train_image = padding(train_image, 2)  # 对初始图像进行零填充，保证与LeNet输入结构一致60000*32*32*1
    test_image = padding(test_image, 2)

    # # ============================Multi-SGD=================================
    population = population_initializer(population_size, seeds=[111, 222, 333, 444, 555])
    optimal = "M-SGD"
    print("{} running:".format(optimal))
    msgd = MSGD(population_size, mini_batch_size, epochs, learning_rate)
    start = time.time()
    Train_Accuracy_msgd, Train_cost_msgd, Test_Accuracy_msgd, \
    Test_cost_msgd, Valid_cost_msgd, Valid_Accuracy_msgd, onetime_msgd = msgd.MSGD(population, train_image, train_label, test_image, test_label,
                                                           train_size, test_size, fitness_size)
    end = time.time()
    time_msgd = (end - start) / 60
    # # ============================ESGD=================================
    population = population_initializer(population_size, seeds=[111, 222, 333, 444, 555])
    optimal = "ESGD"
    print("{} running:".format(optimal))
    esgd = ESGD(population_size, mini_batch_size, epochs, learning_rate,
                    mutate_strength, gd_epochs, evo_epochs)
    start = time.time()
    Train_Accuracy_esgd, Train_cost_esgd, Test_Accuracy_esgd, \
    Test_cost_esgd, Valid_cost_esgd, Valid_Accuracy_esgd, onetime_esgd = esgd.ESGD(population, train_image, train_label, test_image, test_label,
                                                             train_size, test_size, fitness_size)
    end = time.time()
    time_esgd = (end - start) / 60
    # # ============================GDE=================================
    population = population_initializer(population_size, seeds=[111, 222, 333, 444, 555])
    optimal = "GDE"
    print("{} running:".format(optimal))
    gde = GDE(population_size, niche_size, mini_batch_size, epochs,
                mutate_strength, learning_rate, F, fitness_p)
    start = time.time()
    Train_Accuracy_gde, Train_cost_gde, Test_Accuracy_gde,\
    Test_cost_gde, Valid_cost_gde, Valid_Accuracy_gde, onetime_gde = gde.GDE(population, train_image, train_label, test_image, test_label,
                                                            train_size, test_size, fitness_size)
    end = time.time()
    time_gde = (end - start) / 60

    # ==================================draw-results=========================================
    figure_save_path_results = figure_save_path

    Train_Accuracy_list = [Train_Accuracy_msgd, Train_Accuracy_esgd, Train_Accuracy_gde]
    draw_results(Train_Accuracy_list, dataname + " :Train Accuracy", "Train Accuracy", figure_save_path_results)

    Train_cost_list = [Train_cost_msgd,  Train_cost_esgd, Train_cost_gde]
    draw_results(Train_cost_list, dataname + " :Train cost", "Train cost", figure_save_path_results)

    Test_Accuracy_list = [Test_Accuracy_msgd,  Test_Accuracy_esgd, Train_Accuracy_gde]
    draw_results(Test_Accuracy_list, dataname + " :Test Accuracy", "Test Accuracy", figure_save_path_results)

    Test_cost_list = [Test_cost_msgd, Test_cost_esgd, Test_cost_gde]
    draw_results(Test_cost_list, dataname + " :Test cost", "Test cost", figure_save_path_results)

    Valid_Accuracy_list = [Valid_Accuracy_msgd, Valid_Accuracy_esgd, Valid_Accuracy_gde]
    draw_results(Valid_Accuracy_list, dataname + " :Valid Accuracy", "Valid Accuracy", figure_save_path_results)

    Valid_cost_list = [Valid_cost_msgd, Valid_cost_esgd, Valid_cost_gde]
    draw_results(Valid_cost_list, dataname + " :Valid cost", "Valid cost", figure_save_path_results)

    # ==================================time====================
    run_time = [time_msgd, time_esgd, time_gde]
    run_onetime = [onetime_msgd, onetime_esgd, onetime_gde]
    # ======================================================
    tocsv(run_time, run_onetime, figure_save_path, dataname, Train_Accuracy_list, Train_cost_list,
          Test_Accuracy_list, Test_cost_list, Valid_Accuracy_list, Valid_cost_list)
