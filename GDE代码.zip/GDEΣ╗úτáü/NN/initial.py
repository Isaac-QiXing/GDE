import numpy as np


def initializer(seed):
    np.random.seed(seed)

    # 图像变成 28*28*6 池化后图像变成14*14*6
    filters = [np.random.randn(6, 5, 5, 1) / np.sqrt(5)]
    filters_biases = [np.random.randn(6, 1) / np.sqrt(6)]
    # 图像变成 10*10*16 池化后变成5*5*16
    filters.append(np.random.randn(16, 5, 5, 6) / np.sqrt(5))
    filters_biases.append(np.random.randn(16, 1) / np.sqrt(16))

    weights = [np.random.randn(120, 400) / np.sqrt(120)]
    weights.append(np.random.randn(84, 120) / np.sqrt(84))
    weights.append(np.random.randn(10, 84) / np.sqrt(10))

    biases = [np.random.randn(120, 1) / np.sqrt(120)]
    biases.append(np.random.randn(84, 1) / np.sqrt(84))
    biases.append(np.random.randn(10, 1) / np.sqrt(10))

    return [weights, biases, filters, filters_biases]


def population_initializer(population_size, seeds):
    population = []
    for i in range(population_size):
        individual = initializer(seeds[i])
        population.append(individual)
    return population