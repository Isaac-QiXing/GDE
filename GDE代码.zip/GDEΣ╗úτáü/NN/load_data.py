from struct import unpack
import numpy as np
import os
import time

### 导入图片

def read_image(path):
    with open(path, 'rb') as f:
        magic, num, rows, cols = unpack('>4I',f.read(16))
        img = np.fromfile(f, dtype=np.uint8).reshape(num, rows, cols, 1)   # 将图片格式进行规定，加上通道数
    return img

def read_label(path):
    with open(path, 'rb') as f:
        magic, num = unpack('>2I',f.read(8))
        label = np.fromfile(f, dtype=np.uint8)
    return label

def normalize_image(image):
    img = image.astype(np.float32)/255.0
    return img

def one_hot_label(label):
    lab = np.zeros((label.size, 10))
    for i, row in enumerate(lab):
        row[label[i]] = 1
    return lab


# 加载数据集以及数据预处理
def dataset_loader(dir_tr_image, dir_tr_label, dir_te_image, dir_te_label):
    train_image = read_image(dir_tr_image)
    train_label = read_label(dir_tr_label)
    test_image = read_image(dir_te_image)
    test_label = read_label(dir_te_label)
    print(train_image.shape)
    print(test_image.shape)
    print(train_label.shape)
    print(test_label.shape)
    train_image = normalize_image(train_image)
    train_label = one_hot_label(train_label)
    train_label = train_label.reshape(train_label.shape[0], train_label.shape[1], 1)

    test_image = normalize_image(test_image)
    test_label = one_hot_label(test_label)
    test_label = test_label.reshape(test_label.shape[0], test_label.shape[1], 1)
    print(train_image.shape)
    print(test_image.shape)
    print(train_label.shape)
    print(test_label.shape)
    return train_image, train_label, test_image, test_label

# 由于LeNet的输入应该为32×32，但是MNIST手写数字集图片为28×28，我们需要对它进行零填充。
def padding(image, zero_num):
    if len(image.shape) == 4:
        image_padding = np.zeros((image.shape[0],image.shape[1]+2*zero_num,image.shape[2]+2*zero_num,image.shape[3]))
        image_padding[:,zero_num:image.shape[1]+zero_num,zero_num:image.shape[2]+zero_num,:] = image
    elif len(image.shape) == 3:
        image_padding = np.zeros((image.shape[0]+2*zero_num, image.shape[1]+2*zero_num, image.shape[2]))
        image_padding[zero_num:image.shape[0]+zero_num, zero_num:image.shape[1]+zero_num,:] = image
    else:
        print("维度错误")
        sys.exit()
    return image_padding
