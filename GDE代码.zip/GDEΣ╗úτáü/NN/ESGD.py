'''
0722 多点迭代修改LeNet-5
'''
import numpy as np
import matplotlib.pyplot as plt
import os
from load_data import padding
from CNN import add_bias, relu, relu_prime, soft_max
from CNN import conv, conv_cal_w, conv_cal_b
from CNN import pool, pool_delta_error_bp
from CNN import rot180
from load_data import dataset_loader, padding
import time


# LeNet实现
class ESGD():
    def __init__(self, population_size, mini_batch_size, epochs, learning_rate,
                 mutate_strength, gd_epochs, evo_epochs):
        self.population_size = population_size
        self.mini_batch_size = mini_batch_size
        self.learning_rate = learning_rate
        self.M = int(self.population_size/2)
        self.epochs = epochs
        self.gd_epochs = gd_epochs
        self.evo_epochs = evo_epochs
        self.mutate_strength = mutate_strength
        self.t = 0
        self.t_gd = 0
        self.t_evo = 0

    '''
    2卷积 2池化 3全链接
    '''
    def initializer(self):
        # 图像变成 28*28*6 池化后图像变成14*14*6
        filters = [np.random.randn(6, 5, 5, 1) / np.sqrt(5)]
        filters_biases = [np.random.randn(6, 1) / np.sqrt(6)]
        # 图像变成 10*10*16 池化后变成5*5*16
        filters.append(np.random.randn(16, 5, 5, 6) / np.sqrt(5))
        filters_biases.append(np.random.randn(16, 1) / np.sqrt(16))

        weights = [np.random.randn(120, 400) / np.sqrt(120)]
        weights.append(np.random.randn(84, 120) / np.sqrt(84))
        weights.append(np.random.randn(10, 84) / np.sqrt(10))

        biases = [np.random.randn(120, 1) / np.sqrt(120)]
        biases.append(np.random.randn(84, 1) / np.sqrt(84))
        biases.append(np.random.randn(10, 1) / np.sqrt(10))

        return [weights, biases, filters, filters_biases]

    def population_initializer(self):
        population = []
        for i in range(self.population_size):
            individual = self.initializer()
            population.append(individual)
        return population

    def feed_forward(self, x, individual):
        weights, biases, filters, filters_biases = individual[0], individual[1], individual[2], individual[3]
        # 第一层卷积
        conv1 = add_bias(conv(x, filters[0]), filters_biases[0])
        relu1 = relu(conv1)
        pool1, pool1_max_locate = pool(relu1)
        # 第二层卷积
        conv2 = add_bias(conv(pool1, filters[1]), filters_biases[1])
        relu2 = relu(conv2)
        pool2, pool2_max_locate = pool(relu2)
        # 拉直
        straight_input = pool2.reshape(pool2.shape[0] * pool2.shape[1] * pool2.shape[2], 1)
        # 第一层全连接
        full_connect1_z = np.dot(weights[0], straight_input) + biases[0]
        full_connect1_a = relu(full_connect1_z)
        # 第二层全连接
        full_connect2_z = np.dot(weights[1], full_connect1_a) + biases[1]
        full_connect2_a = relu(full_connect2_z)
        # 第三层全连接（输出）
        full_connect3_z = np.dot(weights[2], full_connect2_a) + biases[2]
        full_connect3_a = soft_max(full_connect3_z)
        return full_connect3_a

    def total_cost(self, images, labels, individual):
        J = 0  # 用于记录损失大小
        eta = 1e-7  # 防止计算log溢出
        for img, lab in zip(images, labels):
            predict_label = self.feed_forward(img, individual)
            J = J + sum(-lab * (np.log(predict_label + eta)) - (1 - lab) * (np.log(1 - predict_label + eta)))
        cost = J / len(images)
        return cost[0]  # 以元组形式返回

    def Fitness(self, images, labels, population):
        fitness = [self.total_cost(images, labels, individual) for individual in population]
        return fitness

    def acc(self, images, labels, individual):
        result = 0
        for img, lab in zip(images, labels):
            predict_label = self.feed_forward(img, individual)
            if np.argmax(predict_label) == np.argmax(lab):
                result += 1
        accuracy = result / len(images)
        return accuracy


    def backprop(self, x, y, individual):

        weights, biases, filters, filters_biases = individual[0], individual[1], individual[2], individual[3]
        '''计算通过单幅图像求得梯度'''
        # 先前向传播，求出各中间量
        # 第一层卷积
        conv1 = add_bias(conv(x, filters[0]), filters_biases[0])
        relu1 = relu(conv1)
        pool1, pool1_max_locate = pool(relu1)

        # 第二层卷积
        conv2 = add_bias(conv(pool1, filters[1]), filters_biases[1])
        relu2 = relu(conv2)
        pool2, pool2_max_locate = pool(relu2)

        # 拉直
        straight_input = pool2.reshape(pool2.shape[0] * pool2.shape[1] * pool2.shape[2], 1)

        # 第一层全连接
        full_connect1_z = np.dot(weights[0], straight_input) + biases[0]
        full_connect1_a = relu(full_connect1_z)

        # 第二层全连接
        full_connect2_z = np.dot(weights[1], full_connect1_a) + biases[1]
        full_connect2_a = relu(full_connect2_z)

        # 第三层全连接（输出）
        full_connect3_z = np.dot(weights[2], full_connect2_a) + biases[2]
        full_connect3_a = soft_max(full_connect3_z)

        # 在这里我们使用交叉熵损失，激活函数为softmax，因此delta值就为 a-y，即对正确位置的预测值减1
        delta_fc3 = full_connect3_a - y
        delta_fc2 = np.dot(weights[2].transpose(), delta_fc3) * relu_prime(full_connect2_z)
        delta_fc1 = np.dot(weights[1].transpose(), delta_fc2) * relu_prime(full_connect1_z)
        delta_straight_input = np.dot(weights[0].transpose(), delta_fc1)  # 这里没有激活函数？
        delta_pool2 = delta_straight_input.reshape(pool2.shape)

        delta_conv2 = pool_delta_error_bp(delta_pool2, pool2_max_locate) * relu_prime(conv2)

        # 卷积层误差反向传播
        delta_pool1 = conv(padding(delta_conv2, filters[1].shape[1] - 1), rot180(filters[1]).swapaxes(0, 3))

        delta_conv1 = pool_delta_error_bp(delta_pool1, pool1_max_locate) * relu_prime(conv1)

        # 求各参数的导数
        nabla_w2 = np.dot(delta_fc3, full_connect2_a.transpose())
        nabla_b2 = delta_fc3
        nabla_w1 = np.dot(delta_fc2, full_connect1_a.transpose())
        nabla_b1 = delta_fc2
        nabla_w0 = np.dot(delta_fc1, straight_input.transpose())
        nabla_b0 = delta_fc1

        nabla_filters1 = conv_cal_w(delta_conv2, pool1)
        nabla_filters0 = conv_cal_w(delta_conv1, x)
        nabla_filters_biases1 = conv_cal_b(delta_conv2)
        nabla_filters_biases0 = conv_cal_b(delta_conv1)

        nabla_w = [nabla_w0, nabla_w1, nabla_w2]
        nabla_b = [nabla_b0, nabla_b1, nabla_b2]
        nabla_f = [nabla_filters0, nabla_filters1]
        nabla_fb = [nabla_filters_biases0, nabla_filters_biases1]
        return nabla_w, nabla_b, nabla_f, nabla_fb


    def esgd_gd(self, mini_batch_image, mini_batch_label, individual):
        '''通过一个batch的数据对神经网络参数进行更新
        需要先求这个batch中每张图片的误差反向传播求得的权重梯度以及偏置梯度'''
        weights, biases, filters, filters_biases = individual[0], individual[1], individual[2], individual[3]
        nabla_b = [np.zeros(b.shape) for b in biases]
        nabla_w = [np.zeros(w.shape) for w in weights]
        nabla_f = [np.zeros(f.shape) for f in filters]
        nabla_fb = [np.zeros(fb.shape) for fb in filters_biases]


        for x, y in zip(mini_batch_image, mini_batch_label):
            delta_nabla_w, delta_nabla_b, delta_nabla_f, delta_nabla_fb = self.backprop(x, y, individual)
            nabla_b = [nb + dnb for nb, dnb in zip(nabla_b, delta_nabla_b)]
            nabla_w = [nw + dnw for nw, dnw in zip(nabla_w, delta_nabla_w)]
            nabla_f = [nf + dnf for nf, dnf in zip(nabla_f, delta_nabla_f)]
            nabla_fb = [nfb + dnfb for nfb, dnfb in zip(nabla_fb, delta_nabla_fb)]


        weights = [w - (self.learning_rate / self.mini_batch_size) * nw  for w, nw in zip(weights, nabla_w)]
        biases = [b - (self.learning_rate / self.mini_batch_size) * nb for b, nb in zip(biases, nabla_b)]
        filters = [f - (self.learning_rate / self.mini_batch_size) * nf for f, nf in zip(filters, nabla_f)]
        filters_biases = [fb - (self.learning_rate / self.mini_batch_size) * nfb for fb, nfb in zip(filters_biases, nabla_fb)]

        offspring_individual = [weights, biases, filters, filters_biases]
        return offspring_individual

    def esgd_mutate(self, individual):
        '''通过一个batch的数据对神经网络参数进行更新
        需要先求这个batch中每张图片的误差反向传播求得的权重梯度以及偏置梯度'''
        weights, biases, filters, filters_biases = individual[0], individual[1], individual[2], individual[3]
        mutate_b = [np.zeros(b.shape) for b in biases]
        mutate_w = [np.zeros(w.shape) for w in weights]
        mutate_f = [np.zeros(f.shape) for f in filters]
        mutate_fb = [np.zeros(fb.shape) for fb in filters_biases]

        mutate_b = [np.random.uniform(-self.mutate_strength, self.mutate_strength) for mb in zip(mutate_b)]
        mutate_w = [np.random.uniform(-self.mutate_strength, self.mutate_strength) for mb in zip(mutate_w)]
        mutate_f = [np.random.uniform(-self.mutate_strength, self.mutate_strength) for mb in zip(mutate_f)]
        mutate_fb = [np.random.uniform(-self.mutate_strength, self.mutate_strength) for mb in zip(mutate_fb)]


        weights = [w + mw  for w, mw in zip(weights, mutate_w)]
        biases = [b + mb for b, mb in zip(biases, mutate_b)]
        filters = [f + mf for f, mf in zip(filters, mutate_f)]
        filters_biases = [fb + mfb for fb, mfb in zip(filters_biases, mutate_fb)]

        offspring_individual = [weights, biases, filters, filters_biases]
        return offspring_individual

    def selection(self, population, offspring_population, image, label):
        new_x = []
        fitness = self.Fitness(image, label, population)
        x_idx = np.argsort(fitness)
        offspring_fitness = self.Fitness(image, label, offspring_population)
        off_idx = np.argsort(offspring_fitness)
        x_ite = 0
        off_ite = 0
        for i in range(self.M):
            if offspring_fitness[off_idx[off_ite]] < fitness[x_idx[x_ite]]:
                new_x.append(offspring_population[off_idx[off_ite]])
                off_ite += 1
            else:
                new_x.append(population[x_idx[x_ite]])
                x_ite += 1
        for j in range(self.population_size - self.M):
            if np.random.rand() < 0.5:
                idx = np.random.randint(x_ite + 1, self.population_size)
                new_x.append(population[x_idx[idx]])
            else:
                idx = np.random.randint(off_ite + 1, self.population_size)
                new_x.append(offspring_population[off_idx[idx]])
        population = new_x
        population_backup = population
        return population, population_backup


    def ESGD(self, population, train_image, train_label, test_image, test_label,
             train_size, test_size, fitness_size):

        tr_image, tr_label = train_image[:train_size], train_label[:train_size]
        te_image, te_label = test_image[:test_size], test_label[:test_size]
        mini_batches_image = [tr_image[k:k + self.mini_batch_size] for k in range(0, len(tr_image), self.mini_batch_size)]
        mini_batches_label = [tr_label[k:k + self.mini_batch_size] for k in range(0, len(tr_label), self.mini_batch_size)]
        fitness_image = te_image[:fitness_size]
        fitness_label = te_label[:fitness_size]

        # population = self.population_initializer()
        population_backup = population
        fitness = self.Fitness(fitness_image, fitness_label, population)
        fitness_backup = fitness
        run_time_gd, run_time_evo = [],[]
        history = [np.min(fitness)]

        Train_Accuracy_list, Train_cost_list, Test_Accuracy_list, Test_cost_list, Valid_cost_list, Valid_Accuracy_list = [], [], [], [], [], []

        while self.t < self.epochs:
            while self.t_gd < self.gd_epochs and self.t < self.epochs:
                start_gd = time.time()
                for p in range(len(population)):
                    for mini_batch_image, mini_batch_label in zip(mini_batches_image, mini_batches_label):
                        population[p] = self.esgd_gd(mini_batch_image, mini_batch_label, population[p])
                    fitness[p] = self.total_cost(fitness_image, fitness_label, population[p])
                    if fitness[p] > fitness_backup[p]:
                        population[p] = population_backup[p]
                        fitness[p] = fitness_backup[p]
                    else:
                        population_backup[p] = population[p]
                        fitness_backup[p] = fitness[p]
                self.t += 1
                end_gd = time.time()
                run_time_gd.append(end_gd - start_gd)
                self.t_gd += 1
                fitness = self.Fitness(fitness_image, fitness_label, population)
                history.append(np.min(fitness))
                print("Epoch {} ; SGD Epoch {}".format(self.t, self.t_gd))
                print("min cost in validation data: {} ".format(np.min(fitness)))

                best_index = fitness.index(min(fitness))
                best_individual = population[best_index]

                train_acc = self.acc(tr_image, tr_label, best_individual)
                train_cost = self.total_cost(tr_image, tr_label, best_individual)
                test_acc = self.acc(te_image, te_label, best_individual)
                test_cost = self.total_cost(te_image, te_label,best_individual)
                valid_acc = self.acc(fitness_image, fitness_label, best_individual)


                print("training data: accuracy {}, cost {}".format(train_acc, train_cost))
                print("test data: accuracy {}, cost {}".format(test_acc, test_cost))

                Train_Accuracy_list.append(train_acc)
                Train_cost_list.append(train_cost)
                Test_Accuracy_list.append(test_acc)
                Test_cost_list.append(test_cost)
                Valid_cost_list.append(np.min(fitness))
                Valid_Accuracy_list.append(valid_acc)
            self.t_gd = 0


            while self.t_evo < self.evo_epochs and self.t < self.epochs:
                start_evo = time.time()
                offspring = [self.esgd_mutate(individual) for individual in population]
                population, population_backup = self.selection(population, offspring,
                                                                fitness_image, fitness_label)
                self.t += 1
                end_evo = time.time()
                run_time_evo.append(end_evo - start_evo)
                self.t_evo += 1
                fitness = self.Fitness(fitness_image, fitness_label, population)
                history.append(np.min(fitness))
                print("Epoch {} ; EA Epoch {}".format(self.t, self.t_evo))
                print("min cost in validation data: {} ".format(np.min(fitness)))

                best_index = fitness.index(min(fitness))
                best_individual = population[best_index]

                train_acc = self.acc(tr_image, tr_label, best_individual)
                train_cost = self.total_cost(tr_image, tr_label, best_individual)
                test_acc = self.acc(te_image, te_label, best_individual)
                test_cost = self.total_cost(te_image, te_label, best_individual)
                valid_acc = self.acc(fitness_image, fitness_label, best_individual)

                print("training data: accuracy {}, cost {}".format(train_acc, train_cost))
                print("test data: accuracy {}, cost {}".format(test_acc, test_cost))

                Train_Accuracy_list.append(train_acc)
                Train_cost_list.append(train_cost)
                Test_Accuracy_list.append(test_acc)
                Test_cost_list.append(test_cost)
                Valid_cost_list.append(np.min(fitness))
                Valid_Accuracy_list.append(valid_acc)

            self.t_evo = 0

        return Train_Accuracy_list, Train_cost_list, Test_Accuracy_list, Test_cost_list, Valid_cost_list, Valid_Accuracy_list, [run_time_gd, run_time_evo]




