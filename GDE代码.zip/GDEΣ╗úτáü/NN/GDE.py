'''
0722 多点迭代修改LeNet-5
'''
import numpy as np
import matplotlib.pyplot as plt
import os
from load_data import dataset_loader, padding
from CNN import add_bias, relu, relu_prime, soft_max
from CNN import conv, conv_cal_w, conv_cal_b
from CNN import pool, pool_delta_error_bp
from CNN import rot180
import time


# LeNet实现
class GDE():
    def __init__(self, population_size, niche_size, mini_batch_size, epochs, mutate_strength, learning_rate, F, fitness_p):
        self.population_size = population_size
        self.niche_size = niche_size
        self.mini_batch_size = mini_batch_size
        self.learning_rate = learning_rate
        self.epochs = epochs
        self.F = F
        self.M = int(self.population_size / 2)
        self.fitness_p = fitness_p
        self.mutate_strength = mutate_strength
        self.t = 0


    def feed_forward(self, x, individual):
        weights, biases, filters, filters_biases = individual[0], individual[1], individual[2], individual[3]
        # 第一层卷积
        conv1 = add_bias(conv(x, filters[0]), filters_biases[0])
        relu1 = relu(conv1)
        pool1, pool1_max_locate = pool(relu1)
        # 第二层卷积
        conv2 = add_bias(conv(pool1, filters[1]), filters_biases[1])
        relu2 = relu(conv2)
        pool2, pool2_max_locate = pool(relu2)
        # 拉直
        straight_input = pool2.reshape(pool2.shape[0] * pool2.shape[1] * pool2.shape[2], 1)
        # 第一层全连接
        full_connect1_z = np.dot(weights[0], straight_input) + biases[0]
        full_connect1_a = relu(full_connect1_z)
        # 第二层全连接
        full_connect2_z = np.dot(weights[1], full_connect1_a) + biases[1]
        full_connect2_a = relu(full_connect2_z)
        # 第三层全连接（输出）
        full_connect3_z = np.dot(weights[2], full_connect2_a) + biases[2]
        full_connect3_a = soft_max(full_connect3_z)
        return full_connect3_a

    def total_cost(self, images, labels, individual):
        J = 0  # 用于记录损失大小
        eta = 1e-7  # 防止计算log溢出
        for img, lab in zip(images, labels):
            predict_label = self.feed_forward(img, individual)
            J = J + sum(-lab * (np.log(predict_label + eta)) - (1 - lab) * (np.log(1 - predict_label + eta)))
        cost = J / len(images)
        return cost[0]  # 以元组形式返回

    def Fitness(self, images, labels, population):
        fitness = [self.total_cost(images, labels, individual) for individual in population]
        return fitness

    def acc(self, images, labels, individual):
        result = 0
        for img, lab in zip(images, labels):
            predict_label = self.feed_forward(img, individual)
            if np.argmax(predict_label) == np.argmax(lab):
                result += 1
        accuracy = result / len(images)
        return accuracy

    def fitness_sort(self, images, labels, population):
        Fitness = []
        for i in range(len(population)):
            individual = population[i]
            fitness_cost = self.total_cost(images, labels, individual)
            Fitness.append(fitness_cost)

        Fitness_sort = sorted(zip(population, Fitness), key=lambda x: x[1], reverse=False)
        best_individual = Fitness_sort[0][0]
        return best_individual, Fitness, Fitness_sort

    def backprop(self, x, y, individual):

        weights, biases, filters, filters_biases = individual[0], individual[1], individual[2], individual[3]
        '''计算通过单幅图像求得梯度'''
        # 先前向传播，求出各中间量
        # 第一层卷积
        conv1 = add_bias(conv(x, filters[0]), filters_biases[0])
        relu1 = relu(conv1)
        pool1, pool1_max_locate = pool(relu1)

        # 第二层卷积
        conv2 = add_bias(conv(pool1, filters[1]), filters_biases[1])
        relu2 = relu(conv2)
        pool2, pool2_max_locate = pool(relu2)

        # 拉直
        straight_input = pool2.reshape(pool2.shape[0] * pool2.shape[1] * pool2.shape[2], 1)

        # 第一层全连接
        full_connect1_z = np.dot(weights[0], straight_input) + biases[0]
        full_connect1_a = relu(full_connect1_z)

        # 第二层全连接
        full_connect2_z = np.dot(weights[1], full_connect1_a) + biases[1]
        full_connect2_a = relu(full_connect2_z)

        # 第三层全连接（输出）
        full_connect3_z = np.dot(weights[2], full_connect2_a) + biases[2]
        full_connect3_a = soft_max(full_connect3_z)

        # 在这里我们使用交叉熵损失，激活函数为softmax，因此delta值就为 a-y，即对正确位置的预测值减1
        delta_fc3 = full_connect3_a - y
        delta_fc2 = np.dot(weights[2].transpose(), delta_fc3) * relu_prime(full_connect2_z)
        delta_fc1 = np.dot(weights[1].transpose(), delta_fc2) * relu_prime(full_connect1_z)
        delta_straight_input = np.dot(weights[0].transpose(), delta_fc1)  # 这里没有激活函数？
        delta_pool2 = delta_straight_input.reshape(pool2.shape)

        delta_conv2 = pool_delta_error_bp(delta_pool2, pool2_max_locate) * relu_prime(conv2)

        # 卷积层误差反向传播
        delta_pool1 = conv(padding(delta_conv2, filters[1].shape[1] - 1), rot180(filters[1]).swapaxes(0, 3))

        delta_conv1 = pool_delta_error_bp(delta_pool1, pool1_max_locate) * relu_prime(conv1)

        # 求各参数的导数
        nabla_w2 = np.dot(delta_fc3, full_connect2_a.transpose())
        nabla_b2 = delta_fc3
        nabla_w1 = np.dot(delta_fc2, full_connect1_a.transpose())
        nabla_b1 = delta_fc2
        nabla_w0 = np.dot(delta_fc1, straight_input.transpose())
        nabla_b0 = delta_fc1

        nabla_filters1 = conv_cal_w(delta_conv2, pool1)
        nabla_filters0 = conv_cal_w(delta_conv1, x)
        nabla_filters_biases1 = conv_cal_b(delta_conv2)
        nabla_filters_biases0 = conv_cal_b(delta_conv1)

        nabla_w = [nabla_w0, nabla_w1, nabla_w2]
        nabla_b = [nabla_b0, nabla_b1, nabla_b2]
        nabla_f = [nabla_filters0, nabla_filters1]
        nabla_fb = [nabla_filters_biases0, nabla_filters_biases1]
        return nabla_w, nabla_b, nabla_f, nabla_fb

    def distance(self, w1, w2):
        dis = 0.0
        for k in range(len(w1)):
            x = w1[k]
            y = w2[k]
            dis += (np.square(np.sum((np.array(x) - np.array(y))))) ** 0.5
        return dis

    def p_distance(self, individual1, individual2):
        dist = 0.0
        for i in range(len(individual1)):
            dist += self.distance(individual1[0], individual2[0])
        return dist

        ##种群适应度排序

    def distance_sort(self, individual, population):
        Distance = np.zeros(len(population))
        for i in range(len(population)):
            Distance[i] = self.p_distance(individual, population[i])

        Distance_sort = sorted(zip(population, Distance), key=lambda x: x[1], reverse=False)
        return Distance_sort

    def get_niche(self, images, labels, population):
        Niche = []
        for i in range(int(self.population_size / self.niche_size)):
            best_individual, Fitness, Fitness_sort = self.fitness_sort(images, labels, population)
            Distance_sort = self.distance_sort(best_individual, population)
            population1, niche = [], []
            for j in range(len(Distance_sort)):
                population1.append(Distance_sort[j][0])
            for k in range(self.niche_size):
                niche.append(Distance_sort[k][0])
            Niche.append(niche)
            del population1[:self.niche_size]
            population = population1
        if len(population) != 0:
            Niche.append(population)
        return Niche

    def update1(self, mini_batch_image, mini_batch_label, individual):
        '''通过一个batch的数据对神经网络参数进行更新
        需要先求这个batch中每张图片的误差反向传播求得的权重梯度以及偏置梯度'''
        weights, biases, filters, filters_biases = individual[0], individual[1], individual[2], individual[3]
        nabla_b = [np.zeros(b.shape) for b in biases]
        nabla_w = [np.zeros(w.shape) for w in weights]
        nabla_f = [np.zeros(f.shape) for f in filters]
        nabla_fb = [np.zeros(fb.shape) for fb in filters_biases]


        for x, y in zip(mini_batch_image, mini_batch_label):
            delta_nabla_w, delta_nabla_b, delta_nabla_f, delta_nabla_fb = self.backprop(x, y, individual)
            nabla_b = [nb + dnb for nb, dnb in zip(nabla_b, delta_nabla_b)]
            nabla_w = [nw + dnw for nw, dnw in zip(nabla_w, delta_nabla_w)]
            nabla_f = [nf + dnf for nf, dnf in zip(nabla_f, delta_nabla_f)]
            nabla_fb = [nfb + dnfb for nfb, dnfb in zip(nabla_fb, delta_nabla_fb)]


        weights = [w - (self.learning_rate / self.mini_batch_size) * nw  for w, nw in zip(weights, nabla_w)]
        biases = [b - (self.learning_rate / self.mini_batch_size) * nb for b, nb in zip(biases, nabla_b)]
        filters = [f - (self.learning_rate / self.mini_batch_size) * nf for f, nf in zip(filters, nabla_f)]
        filters_biases = [fb - (self.learning_rate / self.mini_batch_size) * nfb for fb, nfb in zip(filters_biases, nabla_fb)]

        offspring_individual = [weights, biases, filters, filters_biases]
        return offspring_individual

    def update2(self, individual, best_individual, mini_batch_image, mini_batch_label):
        weights, biases, filters, filters_biases = individual[0], individual[1], individual[2], individual[3]
        best_weights, best_biases, best_filters, best_filters_biases = best_individual[0], best_individual[1], best_individual[2], best_individual[3]

        nabla_b = [np.zeros(b.shape) for b in biases]
        nabla_w = [np.zeros(w.shape) for w in weights]
        nabla_f = [np.zeros(f.shape) for f in filters]
        nabla_fb = [np.zeros(fb.shape) for fb in filters_biases]
        for x, y in zip(mini_batch_image, mini_batch_label):
            delta_nabla_w, delta_nabla_b, delta_nabla_f, delta_nabla_fb = self.backprop(x, y, individual)
            nabla_b = [nb + dnb for nb, dnb in zip(nabla_b, delta_nabla_b)]
            nabla_w = [nw + dnw for nw, dnw in zip(nabla_w, delta_nabla_w)]
            nabla_f = [nf + dnf for nf, dnf in zip(nabla_f, delta_nabla_f)]
            nabla_fb = [nfb + dnfb for nfb, dnfb in zip(nabla_fb, delta_nabla_fb)]

        weights = [(w - (self.learning_rate/self.mini_batch_size) * nw + (self.F/self.mini_batch_size) * (best_w - w))
                   for w, nw, best_w in zip(weights, nabla_w, best_weights)]
        biases = [(b - (self.learning_rate / self.mini_batch_size) * nb + (self.F/self.mini_batch_size) * (best_b - b))
                   for b, nb, best_b in zip(biases, nabla_b, best_biases)]
        filters = [f - (self.learning_rate/self.mini_batch_size) * nf + (self.F/self.mini_batch_size) * (best_f - f)
                   for f, nf, best_f in zip(filters, nabla_f, best_filters)]
        filters_biases = [fb - (self.learning_rate / self.mini_batch_size) * nfb + (self.F/self.mini_batch_size) * (best_fb - fb)
                          for fb, nfb, best_fb in zip(filters_biases, nabla_fb, best_filters_biases)]
        offspring_individual = [weights, biases, filters, filters_biases]
        return offspring_individual

    def update3(self, individual, population):
        K = np.random.randint(0, len(population), 2)
        weights, biases, filters, filters_biases = individual[0], individual[1], individual[2], individual[3]
        weights0, biases0, filters0, filters_biases0 = population[K[0]][0], population[K[0]][1],population[K[0]][2], population[K[0]][3]
        weights1, biases1, filters1, filters_biases1 = population[K[1]][0], population[K[1]][1],population[K[0]][2], population[K[0]][3]
        weights = [(w + self.F * (w0 - w1)) for w, w0, w1 in zip(weights, weights0, weights1)]
        biases = [(b + self.F * (b0 - b1)) for b, b0, b1 in zip(biases, biases0, biases1)]
        filters = [f + self.F * (f0 - f1) for f, f0, f1 in zip(filters, filters0, filters1)]
        filters_biases = [fb + self.F * (fb0 - fb1) for fb, fb0, fb1 in zip(filters_biases, filters_biases0, filters_biases1)]
        offspring_individual = [weights, biases, filters, filters_biases]
        return offspring_individual

    def prob(self, cost, Fitness):
        p = (cost - min(Fitness)) / (max(Fitness) - min(Fitness) + 10e-8)
        return p

    def update(self, individual, best_individual, population, Fitness, cost0,
               mini_batch_image, mini_batch_label):
        if self.p_distance(individual, best_individual) == 0:
                offspring_individual = self.update1(mini_batch_image, mini_batch_label, individual)
                return offspring_individual
        else:
            p = self.prob(cost0, Fitness)
            if p > self.fitness_p:
                offspring_individual = self.update3(individual, population)
                return offspring_individual
            else:
                offspring_individual = self.update2(individual, best_individual, mini_batch_image, mini_batch_label)
                return offspring_individual


    def Near_select(self, individual1, cost1, population, offspring_population, images, labels):
        d_sort = self.distance_sort(individual1, population)
        individual_nearest = d_sort[1][0]
        cost_nearest = self.total_cost(images, labels, individual_nearest)
        if cost1 <= cost_nearest:
            offspring_population.append(individual1)
        else:
            offspring_population.append(individual_nearest)
        return offspring_population

    # def M_select(self, population, offspring_population, images, labels):
    #     new_x = []
    #     fitness = self.Fitness(images, labels, population)
    #     x_idx = np.argsort(fitness)
    #     offspring_fitness = self.Fitness(images, labels, offspring_population)
    #     off_idx = np.argsort(offspring_fitness)
    #     x_ite = 0
    #     off_ite = 0
    #     for i in range(self.M):
    #         if offspring_fitness[off_idx[off_ite]] < fitness[x_idx[x_ite]]:
    #             new_x.append(offspring_population[off_idx[off_ite]])
    #             off_ite += 1
    #         else:
    #             new_x.append(population[x_idx[x_ite]])
    #             x_ite += 1
    #     for j in range(self.population_size - self.M):
    #         if np.random.rand() < 0.5:
    #             idx = np.random.randint(x_ite + 1, self.population_size)
    #             new_x.append(population[x_idx[idx]])
    #         else:
    #             idx = np.random.randint(off_ite + 1, self.population_size)
    #             new_x.append(offspring_population[off_idx[idx]])
    #     population = new_x
    #     population_backup = population
    #     return population, population_backup
    #
    # def select(self, images, labels, population):
    #     new_x = []
    #     fitness = self.Fitness(images, labels, population)
    #     x_idx = np.argsort(fitness)
    #     x_ite = 0
    #     for i in range(self.population_size):
    #         new_x.append(population[x_idx[x_ite]])
    #         x_ite += 1
    #     population = new_x
    #     return population

    def GDE(self, population, train_image, train_label, test_image, test_label,
              train_size, test_size, fitness_size):
        tr_image, tr_label = train_image[:train_size], train_label[:train_size]
        te_image, te_label = test_image[:test_size], test_label[:test_size]
        fitness_image = tr_image[:fitness_size]
        fitness_label = tr_label[:fitness_size]

        mini_batches_image = [tr_image[k:k + self.mini_batch_size] for k in
                              range(0, len(tr_image), self.mini_batch_size)]
        mini_batches_label = [tr_label[k:k + self.mini_batch_size] for k in
                              range(0, len(tr_label), self.mini_batch_size)]

        # fitness = self.Fitness(fitness_image, fitness_label, population)
        # history = [np.min(fitness)]
        run_time = []
        Train_Accuracy_list, Train_cost_list, Test_Accuracy_list, Test_cost_list, Valid_cost_list, Valid_Accuracy_list = [], [], [], [], [], []
        while self.t < self.epochs:
            start = time.time()
            Niche = self.get_niche(fitness_image, fitness_label, population)
            offspring_population_L = []
            for i in range(len(Niche)):
                niche = Niche[i]
                best_individual, Fitness, Fitness_sort = self.fitness_sort(fitness_image, fitness_label, niche)
                for individual in niche:
                    cost0 = self.total_cost(fitness_image, fitness_label, individual)
                    for mini_batch_image, mini_batch_label in zip(mini_batches_image, mini_batches_label):
                        individual = self.update(individual, best_individual, population, Fitness, cost0,
                                                 mini_batch_image, mini_batch_label)
                    offspring_individual = individual
                    cost1 = self.total_cost(fitness_image, fitness_label, offspring_individual)
                    offspring_population_L = self.Near_select(offspring_individual, cost1, population,
                                                              offspring_population_L, fitness_image, fitness_label)

            population = offspring_population_L
            # offspring_population_M = []
            # for i in range(len(Niche)):
            #     niche = Niche[i]
            #     best_individual, Fitness, Fitness_sort = self.fitness_sort(fitness_image, fitness_label, niche)
            #     for individual in niche:
            #         cost0 = self.total_cost(fitness_image, fitness_label, individual)
            #         for mini_batch_image, mini_batch_label in zip(mini_batches_image, mini_batches_label):
            #             individual = self.update(individual, best_individual, population, Fitness, cost0,
            #                                      mini_batch_image, mini_batch_label)
            #         offspring_population_M.append(individual)
            #
            # population_M, population_backup = self.M_select(population, offspring_population_M,
            #                                                 fitness_image, fitness_label)
            # population_backup = population_M + population_L
            # population = self.select(fitness_image, fitness_label, population_backup)
            end = time.time()
            run_time.append(end - start)

            self.t += 1
            fitness = self.Fitness(fitness_image, fitness_label, population)
            # Valid_cost_list.append(np.min(fitness))

            print("Epoch {}".format(self.t))
            print("min cost in validation data: {} ".format(np.min(fitness)))

            best_index = fitness.index(min(fitness))
            best_individual = population[best_index]

            train_acc = self.acc(tr_image, tr_label, best_individual)
            train_cost = self.total_cost(tr_image, tr_label, best_individual)
            test_acc = self.acc(te_image, te_label, best_individual)
            test_cost = self.total_cost(te_image, te_label, best_individual)
            valid_acc = self.acc(fitness_image, fitness_label, best_individual)


            print("training data: accuracy {}, cost {}".format(train_acc, train_cost))
            print("test data: accuracy {}, cost {}".format(test_acc, test_cost))

            Train_Accuracy_list.append(train_acc)
            Train_cost_list.append(train_cost)
            Test_Accuracy_list.append(test_acc)
            Test_cost_list.append(test_cost)
            Valid_cost_list.append(np.min(fitness))
            Valid_Accuracy_list.append(valid_acc)


        return Train_Accuracy_list, Train_cost_list, Test_Accuracy_list, Test_cost_list, Valid_cost_list, Valid_Accuracy_list, run_time









